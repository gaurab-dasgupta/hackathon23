// import React from "react";
import {
  BsFillArchiveFill,
  BsFillGrid3X3GapFill,
  BsPeopleFill,
  BsFillBellFill,
  // BsLayoutSidebar,
} from "react-icons/bs";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LabelList,
  RadialBar,
  RadialBarChart,
  // Cell,
  // Pie,
  // PieChart,
} from "recharts";
// import Chart from "chart.js";

function Home() {
  // Sample data
  const dataB = [
    { name: "A", created: 110 },
    { name: "B", approved: 80, notapproved: 30 },
    { name: "C", integrated: 65, not_integrated: 15, other: 30 },
  ];
  // const dataC = [
  //   { name: "created", value: "70%" },
  //   { name: "pending", value: "30%" },
  // ];

  const dataC = [
    {
      name: "pending",
      status: 70,
      pv: 4567,
      fill: "yellow",
      background: "orange",
    },
    {
      name: "created",
      status: 100,
      pv: 2400,
      fill: "green",
    },
  ];

  const dataD = [
    { name: "Created", value: 70, fill: "#0088FE" },
    { name: "Pending", value: 30, fill: "yellow" },
  ];

  const dataE = [
    { name: "A", Amended: 110 },
    { name: "B", integrated: 80, pending: 30 },
  ];

  return (
    <main className="main-container">
      <div className="main-title">
        <h3>PRODUCT DASHBOARD</h3>
        <h4> Period: 02-OCt-2024 to 08-Oct-2024 </h4>
      </div>

      {/* <div className="main-cards">
        <div className="card">
          <div className="card-inner">
            <h3>PRODUCTS</h3>
            <BsFillArchiveFill className="card_icon" />
          </div>
          <h1>300</h1>
        </div>
        <div className="card">
          <div className="card-inner">
            <h3>CATEGORIES</h3>
            <BsFillGrid3X3GapFill className="card_icon" />
          </div>
          <h1>12</h1>
        </div>
        <div className="card">
          <div className="card-inner">
            <h3>CUSTOMERS</h3>
            <BsPeopleFill className="card_icon" />
          </div>
          <h1>33</h1>
        </div>
        <div className="card">
          <div className="card-inner">
            <h3>ALERTS</h3>
            <BsFillBellFill className="card_icon" />
          </div>
          <h1>42</h1>
        </div>
      </div> */}

      <div className="charts">
        <h1>Product Integration Status</h1>
        <ResponsiveContainer width="60%" height="50%">
          <BarChart
            width={100}
            height={100}
            data={dataB}
            layout="vertical"
            label="Product Integration Status"
          >
            {/* <CartesianGrid stroke="#ccc" /> */}

            <XAxis type="number" />
            <YAxis
              dataKey="name" //{dataB}
              type="category"
              hide
              orientation="right"
              mirror
            />
            <Tooltip />
            <Legend />
            <Bar label="test" dataKey="created" stackId="a" fill="blue" />
            <LabelList
              dataKey="name"
              position="inside"
              style={{ fill: "balck" }}
            />
            {/* <Bar dataKey="pending" stackId="a" fill="orange" /> */}

            <Bar dataKey="approved" stackId="a" fill="green" />
            <Bar dataKey="notapproved" stackId="a" fill="orange" />

            <Bar dataKey="integrated" stackId="a" fill="#90EE90" />
            <Bar dataKey="not_integrated" stackId="a" fill="pink" />
            <Bar dataKey="other" stackId="a" fill="#1d2634" />
          </BarChart>
        </ResponsiveContainer>

        <h1>Integration Status</h1>
        <RadialBarChart
          width={400}
          height={400}
          innerRadius="70%"
          outerRadius="120%"
          data={dataC}
          startAngle={180}
          endAngle={0}
        >
          <RadialBar
            label={{
              fill: "black",
              fontWeight: "bold",
              position: "insideStart",
            }}
            background
            clockWise={true}
            dataKey="status"
          />
          <text
            x="50%"
            y="50%"
            style={{ fontSize: 20, fontWeight: "bold", fill: "#22AA22" }}
            width={200}
            // scaleToFit={true}
            textAnchor="middle"
            // verticalAnchor='middle'
          >
            %SCORE
          </text>
          {/* <text
            x="50%"
            y="60%"
            style={{ fontSize: 24, fontWeight: "bold", fill: "orange" }}
            width={200}
            // scaleToFit={true}
            textAnchor="middle"
            // verticalAnchor='middle'
          ></text> */}
          <Legend
            iconSize={20}
            width={100}
            height={100}
            layout="vertical"
            verticalAlign="bottom"
            align="center"
          />
          <Tooltip />
        </RadialBarChart>
      </div>

      <div className="charts2">
        <h1>Product Amended Status</h1>
        <ResponsiveContainer width="60%" height="50%">
          <BarChart
            width={200}
            height={200}
            data={dataE}
            layout="vertical"
            label="Product Integration Status"
          >
            {/* <CartesianGrid stroke="#ccc" /> */}

            <XAxis type="number" />
            <YAxis
              dataKey={dataE}
              type="category"
              hide
              orientation="right"
              mirror
            />
            <Tooltip />
            <Legend />
            <Bar label="test" dataKey="Amended" stackId="b" fill="blue" />
            <LabelList
              dataKey="name"
              position="inside"
              style={{ fill: "balck" }}
            />
            {/* <Bar dataKey="pending" stackId="a" fill="orange" /> */}

            <Bar dataKey="integrated" stackId="b" fill="green" />
            <Bar dataKey="pending" stackId="b" fill="orange" />
            {/* 
            <Bar dataKey="integrated" stackId="a" fill="#90EE90" />
            <Bar dataKey="not_integrated" stackId="a" fill="pink" />
            <Bar dataKey="other" stackId="a" fill="#1d2634" /> */}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </main>
  );
}

export default Home;
