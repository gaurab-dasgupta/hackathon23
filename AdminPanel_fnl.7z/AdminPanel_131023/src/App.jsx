// import React from "react";
import "./App.css";
// import Header from "./pages/Header";
import Sidebar from "./components/Sidebar";
import Home from "./pages/Home";
import LifeCycle from "./pages/LifeCycle";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Zendesk from "./pages/Zendesk";

const App = () => {
  // const [openSidebarToggle, setOpenSidebarToggle] = useState(false);

  // const OpenSidebar = () => {
  //   setOpenSidebarToggle(!openSidebarToggle);
  // };

  return (
    // <div className="grid-container">
    //   <Header OpenSidebar={OpenSidebar} />
    //   <Sidebar
    //     openSidebarToggle={openSidebarToggle}
    //     OpenSidebar={OpenSidebar}
    //   />
    //   <Home />
    <BrowserRouter>
      <Sidebar>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/LifeCycle" element={<LifeCycle />} />
          <Route path="/Zendesk" element={<Zendesk />} />
        </Routes>
      </Sidebar>
    </BrowserRouter>
    // </div>
  );
};

export default App;
