import React, { useState } from "react";
import {
  // BsCart3,
  BsGrid1X2Fill,
  BsFillArchiveFill,
  // BsFillGrid3X3GapFill,
  BsPeopleFill,
  // BsListCheck,
  // BsMenuButtonWideFill,
  // BsFillGearFill,
} from "react-icons/bs";
import {
  // FaTh,
  FaBars,
  // FaUserAlt,
  // FaRegChartBar,
  // FaCommentAlt,
  // FaShoppingBag,
  // FaThList
} from "react-icons/fa";
import { NavLink } from "react-router-dom";
// import LifeCycle from "../pages/LifeCycle";

const Sidebar = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const toggle = () => setIsOpen(!isOpen);

  const menuItem = [
    { path: "/", name: "DASHBOARD", icon: <BsGrid1X2Fill /> },
    {
      path: "/LifeCycle",
      name: "PRODUCT",
      icon: <BsFillArchiveFill />,
    },
    {
      path: "https://tescosupportcentre.zendesk.com/",
      name: "ZENDESK",
      icon: <BsPeopleFill />,
    },
  ];
  return (
    <div className="container">
      <div style={{ width: isOpen ? "200px" : "500px" }} className="sidebar">
        <div className="top_section">
          <h1
            style={{ display: isOpen ? "block" : "none" }}
            className="logo"
          ></h1>
          <div style={{ marginLeft: isOpen ? "50px" : "0px" }} className="bars">
            <FaBars onClick={toggle} />
          </div>
        </div>
        {menuItem.map((item, index) => (
          <NavLink
            to={item.path}
            key={index}
            className="link"
            activeclassName="active"
          >
            <div className="icon">{item.icon}</div>
            <div
              style={{ display: isOpen ? "block" : "none" }}
              className="link_text"
            >
              {item.name}
            </div>
          </NavLink>
        ))}
      </div>
      <main>{children}</main>
    </div>
  );
};

//   return (
//     <aside
//       id="sidebar"
//       className={openSidebarToggle ? "sidebar-responsive" : ""}
//     >
//       <div className="sidebar-title">
//         <div className="sidebar-brand">
//           <BsCart3 className="icon_header" /> Navigate
//         </div>
//         <span className="icon close_icon" onClick={OpenSidebar}>
//           X
//         </span>
//       </div>

//       <ul className="sidebar-list">
//         <li className="sidebar-list-item">
//           <a href="">
//             <BsGrid1X2Fill className="icon" /> Dashboard
//           </a>
//         </li>

//         <li className="sidebar-list-item">
//           <a href={LifeCycle} >
//             <BsFillArchiveFill className="icon" /> Products
//           </a>
//         </li>

//         {/* <li className="sidebar-list-item">
//           <a href="">
//             <BsFillGrid3X3GapFill className="icon" /> Categories
//           </a>
//         </li> */}
//         <li className="sidebar-list-item">
//           <a href="https://tescosupportcentre.zendesk.com/">
//             <BsPeopleFill className="icon" /> Zendesk
//           </a>
//         </li>
//         {/* <li className="sidebar-list-item">
//           <a href="">
//             <BsListCheck className="icon" /> Inventory
//           </a>
//         </li>
//         <li className="sidebar-list-item">
//           <a href="">
//             <BsMenuButtonWideFill className="icon" /> Reports
//           </a>
//         </li>
//         <li className="sidebar-list-item">
//           <a href="">
//             <BsFillGearFill className="icon" /> Setting
//           </a>
//         </li> */}
//       </ul>
//     </aside>
//   );
// }

export default Sidebar;
