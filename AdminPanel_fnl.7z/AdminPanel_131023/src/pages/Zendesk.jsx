// import React from "react";

const Zendesk = () => {
  return (
    <div>
      <h1>Redirect to Zedesk page</h1>
      <a href="https://tescosupportcentre.zendesk.com/"></a>
    </div>
  );
};

export default Zendesk;
