// import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  // CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LabelList,
  RadialBar,
  RadialBarChart,
  // Cell,
  // Pie,
  // PieChart,
} from "recharts";
import logo from "../images/Tesco.png";

const LifeCycle = () => {
  // Sample data
  const dataB = [
    { name: "MPI StoreReady / Draft", Store_Ready: 110, Drafts: 70 },
    {
      name: "Supplier / Buyer / DataOps",
      others: 110,
      supplier: 10,
      buyer: 50,
      dataops: 10,
    },
    {
      name: "RMS Integrated / Pending / Deactived",
      rms_integrated: 65,
      rms_not_integrated: 15,
      deactivated: 30,
      others1: 70,
    },
    {
      name: "IL / ODS / PS",
      rmsil_integrated: 55,
      rmsil_not_integrated: 10,
      others2: 115,
    },
    {
      name: "Retal Platform",
      SL_integrated: 50,
      SL_not_integrated: 5,
      others3: 125,
    },
  ];
  // const dataC = [
  //   { name: "created", value: "70%" },
  //   { name: "pending", value: "30%" },
  // ];

  const dataC = [
    {
      name: "pending",
      status: 70,
      pv: 4567,
      fill: "yellow",
      background: "orange",
    },
    {
      name: "created",
      status: 100,
      pv: 2400,
      fill: "green",
    },
  ];

  return (
    <main className="main-container">
      <img src={logo} alt="" />
      <h1>PRODUCT LIFECYLE STATUS</h1>
      <div className="main-title"></div>
      <h2> Period: 02-OCt-2024 to 08-Oct-2024 </h2>

      <div className="charts">
        <h1>myProduct: Induct</h1>
        <ResponsiveContainer width={"100%"} height={550}>
          <BarChart
            width={900}
            // height={100}
            data={dataB}
            layout="vertical"
            margin={{ left: 50, right: 50 }}
            stackOffset="expand"
          >
            {/* <CartesianGrid stroke="#ccc" /> */}

            <XAxis hide type="number" />
            <YAxis
              dataKey="name" //{dataB}
              type="category"
              stroke="#FFFFFF"
              fontSize="18"
              fontWeight="Bold"
              // hide
              orientation="left"
              display="flex"
              // mirror
            />
            <Tooltip />
            <Legend />

            <LabelList
              dataKey={dataB}
              position="inside"
              style={{ fill: "balck" }}
            />

            <Bar dataKey="Store_Ready" stackId="a" fill="green">
              <LabelList
                dataKey="Store_Ready"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"Store_Ready"}
              />
            </Bar>
            <Bar dataKey="Drafts" stackId="a" fill="orange">
              <LabelList
                dataKey="Drafts"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"Drafts"}
              />
            </Bar>

            <Bar dataKey="others" stackId="a" fill="rgba(0,0,0,0)">
              <LabelList
                dataKey="others"
                position="center"
                fill="rgba(0,0,0,0)"
                // fontSize="12"
                fontWeight="Bold"
                content={"others"}
              />
            </Bar>
            <Bar dataKey="supplier" stackId="a" fill="#90EE90">
              <LabelList
                dataKey="supplier"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"supplier"}
              />
            </Bar>
            <Bar dataKey="buyer" stackId="a" fill="pink">
              <LabelList
                dataKey="buyer"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"buyer"}
              />
            </Bar>
            <Bar dataKey="dataops" stackId="a" fill="yellow">
              <LabelList
                dataKey="dataops"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"dataops"}
              />
            </Bar>

            <Bar dataKey="rms_integrated" stackId="a" fill="#90EE90">
              <LabelList
                dataKey="rms_integrated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                // content={"dataops"}
              />
            </Bar>
            <Bar dataKey="rms_not_integrated" stackId="a" fill="pink">
              <LabelList
                dataKey="rms_not_integrated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"rms_not_integrated"}
              />
            </Bar>
            <Bar dataKey="deactivated" stackId="a" fill="yellow">
              <LabelList
                dataKey="deactivated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                // content={"dataops"}
              />
            </Bar>
            <Bar dataKey="others1" stackId="a" fill="rgba(0,0,0,0)">
              <LabelList
                dataKey="others1"
                position="center"
                fill="rgba(0,0,0,0)"
                fontSize="25"
                fontWeight="Bold"
                // content={"dataops"}
              />
            </Bar>

            <Bar dataKey="rmsil_integrated" stackId="a" fill="#90EE90">
              <LabelList
                dataKey="rmsil_integrated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                // content={"dataops"}
              />
            </Bar>
            <Bar dataKey="rmsil_not_integrated" stackId="a" fill="pink">
              <LabelList
                dataKey="rmsil_not_integrated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                // content={"dataops"}
              />
            </Bar>
            <Bar dataKey="others2" stackId="a" fill="rgba(0,0,0,0)">
              <LabelList
                dataKey="others2"
                position="center"
                fill="rgba(0,0,0,0)"
                fontSize="25"
                fontWeight="Bold"
                // content={"dataops"}
              />
            </Bar>

            <Bar dataKey="SL_integrated" stackId="a" fill="#90EE90">
              <LabelList
                dataKey="SL_integrated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"SL_integrated"}
              />
            </Bar>
            <Bar dataKey="SL_not_integrated" stackId="a" fill="pink">
              <LabelList
                dataKey="SL_not_integrated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"SL_not_integrated"}
              />
            </Bar>
            <Bar dataKey="others3" stackId="a" fill="rgba(0,0,0,0)">
              <LabelList
                dataKey="others3"
                position="center"
                fill="rgba(0,0,0,0)"
                fontSize="25"
                fontWeight="Bold"
                // content={"others3"}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>

        <h1>Overall Status</h1>
        <RadialBarChart
          width={1400}
          height={500}
          innerRadius="70%"
          outerRadius="120%"
          data={dataC}
          startAngle={180}
          endAngle={0}
        >
          <RadialBar
            label={{
              fill: "black",
              fontWeight: "bold",
              position: "insideStart",
            }}
            background
            clockWise={true}
            dataKey="status"
          />
          <text
            x="50%"
            y="50%"
            style={{ fontSize: 20, fontWeight: "bold", fill: "#22AA22" }}
            width={200}
            // scaleToFit={true}
            textAnchor="middle"
            // verticalAnchor='middle'
          >
            %SCORE
          </text>
          <Legend
            iconSize={20}
            width={100}
            height={100}
            layout="vertical"
            verticalAlign="bottom"
            align="center"
          />
          <Tooltip />
        </RadialBarChart>
      </div>
    </main>
  );
};

export default LifeCycle;
