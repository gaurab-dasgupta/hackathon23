// import React from "react";
// import React from "react";
import // BsFillArchiveFill,
// BsFillGrid3X3GapFill,
// BsPeopleFill,
// BsFillBellFill,
// BsLayoutSidebar,
"react-icons/bs";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  // CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LabelList,
  RadialBar,
  RadialBarChart,
  // Cell,
  // Pie,
  // PieChart,
} from "recharts";
import logo from "../images/Tesco.png";

function Home() {
  // Sample data
  const dataB = [
    { name: "Product Created", created: 110 },
    { name: "Product Approved / Pending", approved: 80, not_approved: 30 },
    {
      name: "Integrated / Pending",
      integrated: 65,
      not_integrated: 15,
      other: 30,
    },
  ];

  const dataC = [
    {
      name: "pending",
      status: 70,
      pv: 4567,
      fill: "yellow",
      background: "orange",
    },
    {
      name: "created",
      status: 100,
      pv: 2400,
      fill: "green",
    },
  ];

  const dataE = [
    { name: "Product Amended", Amended: 110 },
    { name: "Integrated / Pending", integrated: 80, pending: 30 },
  ];

  return (
    <main className="main-container">
      <img src={logo} alt="" />
      <h1>PRODUCT DASHBOARD</h1>

      <div className="main-title">
        <h2> Period: 02-OCt-2024 to 08-Oct-2024 </h2>
      </div>

      <div className="charts">
        <h1>Product Integration Status</h1>

        <ResponsiveContainer height={250} width={"100%"}>
          <BarChart
            width={800}
            // height={100}
            data={dataB}
            layout="vertical"
            margin={{ left: 50, right: 50 }}
            stackOffset="expand"
          >
            {/* <CartesianGrid stroke="#ccc" /> */}

            <XAxis hide type="number" />
            <YAxis
              dataKey="name" //{dataB}
              type="category"
              stroke="#FFFFFF"
              fontSize="20"
              fontWeight="Bold"
              // hide
              orientation="left"
              display="flex"
            />
            <Tooltip />
            <Legend />
            <Bar dataKey="created" stackId="a" fill="blue">
              <LabelList
                dataKey="created"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"created"}
              />
            </Bar>

            <Bar dataKey="approved" stackId="a" fill="green">
              <LabelList
                dataKey="approved"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"approved"}
              />
            </Bar>
            <Bar dataKey="not_approved" stackId="a" fill="orange">
              <LabelList
                dataKey="not_approved"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"not_approved"}
              />
            </Bar>

            <Bar dataKey="integrated" stackId="a" fill="#90EE90">
              <LabelList
                dataKey="integrated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"integrated"}
              />
            </Bar>
            <Bar dataKey="not_integrated" stackId="a" fill="pink">
              <LabelList
                dataKey="not_integrated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"not_integrated"}
              />
            </Bar>
            <Bar dataKey="other" stackId="a" fill="rgba(0,0,0,0)">
              <LabelList
                dataKey="other"
                position="center"
                fill="rgba(0,0,0,0)" // "=#1d2634"
                fontSize="25"
                fontWeight="Bold"
                content={"other"}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>

        <h1>Integration Status</h1>
        <RadialBarChart
          width={1400}
          height={700}
          innerRadius="70%"
          outerRadius="120%"
          data={dataC}
          startAngle={180}
          endAngle={0}
          display="auto"
        >
          <RadialBar
            label={{
              fill: "black",
              fontWeight: "bold",
              position: "insideStart",
            }}
            background
            clockWise={true}
            dataKey="status"
          />
          <text
            x="50%"
            y="50%"
            style={{ fontSize: 25, fontWeight: "bold", fill: "#22AA22" }}
            width={200}
            // scaleToFit={true}
            textAnchor="middle"
            // verticalAnchor='middle'
          >
            %SCORE
          </text>
          {/* <text
            x="50%"
            y="60%"
            style={{ fontSize: 24, fontWeight: "bold", fill: "orange" }}
            width={200}
            // scaleToFit={true}
            textAnchor="middle"
            // verticalAnchor='middle'
          ></text> */}
          <Legend
            iconSize={20}
            width={100}
            height={100}
            layout="vertical"
            verticalAlign="bottom"
            align="center"
          />
          <Tooltip />
        </RadialBarChart>
      </div>

      <div className="charts2">
        <h1>Product Amended Status</h1>
        <ResponsiveContainer height={250} width={"100%"}>
          <BarChart
            // width={800}
            // height={100}
            data={dataE}
            layout="vertical"
            margin={{ left: 50, right: 50 }}
            stackOffset="expand"
          >
            {/* <CartesianGrid stroke="#ccc" /> */}

            <XAxis hide type="number" />
            <YAxis
              dataKey="name"
              type="category"
              stroke="#FFFFFF"
              fontSize={20}
              fontWeight="bold"
              // hide
              orientation="left"
              // mirror
            />
            <Tooltip />
            <Legend />
            <Bar dataKey="Amended" stackId="b" fill="blue">
              <LabelList
                dataKey="Amended"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"Amended"}
              />
            </Bar>

            <Bar dataKey="integrated" stackId="b" fill="green">
              <LabelList
                dataKey="integrated"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"integrated"}
              />
            </Bar>
            <Bar dataKey="pending" stackId="b" fill="orange">
              <LabelList
                dataKey="pending"
                position="center"
                fill="black"
                fontSize="25"
                fontWeight="Bold"
                content={"pending"}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </main>
  );
}

export default Home;
